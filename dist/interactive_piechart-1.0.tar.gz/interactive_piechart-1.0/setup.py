from distutils.core import setup
setup(name='interactive_piechart',
	version = '1.0',
	py_modules = ['interactive_piechart'],
	)